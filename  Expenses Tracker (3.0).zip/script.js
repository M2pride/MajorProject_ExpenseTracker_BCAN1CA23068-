const desc = document.getElementById("desc");
const amount = document.getElementById("amount");
const category = document.getElementById("category");
const list = document.getElementById("list");

const balanceEl = document.getElementById("balance");
const incomeEl = document.getElementById("income");
const expenseEl = document.getElementById("expense");
const monthlyText = document.getElementById("monthlyText");

let transactions = JSON.parse(localStorage.getItem("transactions")) || [];
let filter = "all";
let chart;

document.getElementById("addBtn").addEventListener("click", addTransaction);

function addTransaction() {
  if (desc.value === "" || amount.value === "") return;

  const transaction = {
    id: Date.now(),
    desc: desc.value,
    amount: parseFloat(amount.value),
    category: category.value,
    date: new Date().toISOString()
  };

  transactions.push(transaction);
  localStorage.setItem("transactions", JSON.stringify(transactions));

  desc.value = "";
  amount.value = "";

  render();
}

function setFilter(type) {
  filter = type;
  render();
}

function deleteTransaction(id) {
  transactions = transactions.filter(t => t.id !== id);
  localStorage.setItem("transactions", JSON.stringify(transactions));
  render();
}

function render() {
  list.innerHTML = "";

  let balance = 0;
  let income = 0;
  let expense = 0;

  const now = new Date();

  let monthlyIncome = 0;
  let monthlyExpense = 0;

  transactions.forEach(t => {

    if (filter === "income" && t.amount < 0) return;
    if (filter === "expense" && t.amount > 0) return;

    balance += t.amount;

    if (t.amount > 0) income += t.amount;
    else expense += t.amount;

    const date = new Date(t.date);
    if (date.getMonth() === now.getMonth()) {
      if (t.amount > 0) monthlyIncome += t.amount;
      else monthlyExpense += Math.abs(t.amount);
    }

    const li = document.createElement("li");
    li.classList.add(t.amount > 0 ? "income" : "expense");

    li.innerHTML = `
      <span>
        ${t.desc} (${t.category})<br>
        <small>${date.toLocaleDateString()}</small>
      </span>
      <span>
        ₹${t.amount}
        <button onclick="deleteTransaction(${t.id})" class="delete-btn">X</button>
      </span>
    `;

    list.appendChild(li);
  });

  balanceEl.innerText = balance;
  incomeEl.innerText = income;
  expenseEl.innerText = Math.abs(expense);

  monthlyText.innerText = 
    `This Month → Income: ₹${monthlyIncome} | Expense: ₹${monthlyExpense}`;

  updateChart(monthlyIncome, monthlyExpense);
}

function updateChart(income, expense) {
  const ctx = document.getElementById("chart").getContext("2d");

  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Income", "Expense"],
      datasets: [{
        data: [income, expense],
        backgroundColor: ["green", "red"]
      }]
    }
  });
}

render();